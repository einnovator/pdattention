import numpy as np
from sklearn.preprocessing import KBinsDiscretizer

# Test case from the issue description
X = np.array([0, 0.5, 2, 3, 9, 10]).reshape(-1, 1)
print("Original data:", X.ravel())

try:
    # This should work now with our fix
    est = KBinsDiscretizer(n_bins=5, strategy='kmeans', encode='ordinal')
    Xt = est.fit_transform(X)
    print("Success! Transformed data:", Xt.ravel())
    print("Bin edges:", est.bin_edges_[0])
    
    # Verify bin edges are sorted
    edges = est.bin_edges_[0]
    is_sorted = np.all(edges[:-1] <= edges[1:])
    print("Are bin edges sorted?", is_sorted)
    
except Exception as e:
    print("Error:", str(e))
    import traceback
    traceback.print_exc()
