#!/usr/bin/env python3
import numpy as np
from sklearn.preprocessing import KBinsDiscretizer

# Test case from the issue description
X = np.array([0, 0.5, 2, 3, 9, 10]).reshape(-1, 1)
print("Input data:", X.ravel())

try:
    # This should work now with our fix
    est = KBinsDiscretizer(n_bins=5, strategy='kmeans', encode='ordinal')
    Xt = est.fit_transform(X)
    print("Success! Transformed data:", Xt.ravel())
    
    # Check bin edges are sorted
    print("Bin edges for each feature:")
    for i, edges in enumerate(est.bin_edges_):
        print(f"Feature {i}: {edges}")
        is_sorted = np.all(edges[:-1] <= edges[1:])
        print(f"  Is sorted: {is_sorted}")
        
except Exception as e:
    print("Error occurred:", str(e))
    print("Type of error:", type(e).__name__)
    
print("\nTesting with different parameters...")
# Test with a few more cases
try:
    est2 = KBinsDiscretizer(n_bins=3, strategy='kmeans', encode='ordinal')
    Xt2 = est2.fit_transform(X)
    print("Success with 3 bins!")
    for i, edges in enumerate(est2.bin_edges_):
        is_sorted = np.all(edges[:-1] <= edges[1:])
        print(f"Feature {i} bin edges sorted: {is_sorted}")
except Exception as e:
    print("Error with 3 bins:", str(e))
