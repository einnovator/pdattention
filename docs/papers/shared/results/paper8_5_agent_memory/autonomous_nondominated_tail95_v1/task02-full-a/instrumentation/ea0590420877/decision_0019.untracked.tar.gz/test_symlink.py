import os; print("Testing symlink behavior"); os.symlink("test", "link"); print("Symlink created successfully")
